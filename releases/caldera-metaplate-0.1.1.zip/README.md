caldera-metaplate
=================

[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/Desertsnowman/caldera-metaplate/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/Desertsnowman/caldera-metaplate/?branch=master)

Automatic metadata &amp; custom field templates for WordPress
